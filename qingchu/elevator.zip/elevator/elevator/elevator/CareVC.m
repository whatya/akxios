//
//  CareVC.m
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "CareVC.h"
#import "CommonConstants.h"
#import "ProgressHUD.h"
#import "DeviceMaintRequest.h"
#import "CareCell.h"
#import "TaskResult.h"
#import "Sugar.h"
#import "Tracker.h"

@interface CareVC ()
<UITableViewDataSource,
UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) DeviceMaintRequest *manager;
@property (nonatomic,strong) NSMutableArray *devices;

//选中id
@property (nonatomic,strong) NSString *selectedDeviceID;
@property (nonatomic,strong) NSString *selectedTaskID;

@end

@implementation CareVC

#define CellID @"CareCell"

- (void)viewDidLoad {
    [super viewDidLoad];
    self.manager = [[DeviceMaintRequest alloc] init];
    self.devices = [NSMutableArray new];
    [self deviceList];
}

- (void)deviceList
{
    [ProgressHUD show:@"获取保养列表中..."];
    [self.manager getPendingDeviceMaintTask:^(NSString *errorMsg, NSArray *maintTaskList) {
        if (errorMsg) {
            [ProgressHUD showError:errorMsg];
            return ;
        }
        [ProgressHUD dismiss];
        [self.devices addObjectsFromArray:maintTaskList];
        [self.tableView reloadData];
    }];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.devices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CareCell *cell = [tableView dequeueReusableCellWithIdentifier:CellID];
    Ddevice *model = self.devices[indexPath.row];
    cell.model = model;
    
    //设置task点击事件
    cell.TaskSelect = ^(NSIndexPath *indexPath){
      
        MaintTaskDetail *task = model.maintTaskDetailList[indexPath.row];
        self.selectedTaskID = [NSString stringWithFormat:@"%@",task.taskDetailID];
        if (task.needUploadImage){// && ![task.isFinished boolValue]) {
            UINavigationController *nav = VCFromStoryboard(@"Main", @"ScannerNav");
            [nav.topViewController setValue:self forKey:@"delegate"];
            [self presentViewController:nav animated:YES completion:NULL];
        }
        
    };
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Ddevice *model = self.devices[indexPath.row];
    return model.cellHight;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    Ddevice *model = self.devices[indexPath.row];
    self.selectedDeviceID = [NSString stringWithFormat:@"%@",model.deviceID];
    model.isOpend = !model.isOpend;
    CareCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (model.isOpend) {
        [cell open];
    }else{
        [cell close];
    }
    [self.tableView beginUpdates];
    [self.tableView endUpdates];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    [ProgressHUD dismiss];
}

- (void)setBarCode:(NSString *)barCode
{
    _barCode = barCode;
    [ProgressHUD show:@"处理中..."];
    NSLog(@"barcode got:%@",barCode);
    //提交参数model
    TaskResult *task = [[TaskResult alloc] init];
    task.checkDateTime = [self currentDateString];//上传时间
    task.deviceImageType = @"DeviceMaintResult";//维修／保养
    task.deviceTaskId = self.selectedTaskID;//任务id
    task.deviceNumber = barCode;//二维码
    task.fileName = @"";
    task.latitude = [NSString stringWithFormat:@"%.4f",[Tracker shared].lat];
    task.longitude = [NSString stringWithFormat:@"%.4f",[Tracker shared].lon];
    task.userLicenseCode = [Sugar loginUser].userLicenseCode;
    
    
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        PUSH(@"Main", @"ImageMakerVC", @"照片", @{@"task":task}, YES);
    });
}

- (NSString*)currentDateString
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    return [formatter stringFromDate:[NSDate date]];
}

@end
