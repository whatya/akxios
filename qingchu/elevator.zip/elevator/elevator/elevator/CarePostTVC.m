//
//  CarePostTVC.m
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "CarePostTVC.h"
#import "CommonConstants.h"
#import "DeviceMaintRequest.h"
#import "ProgressHUD.h"
#import "DeviceBugRequest.h"
@interface CarePostTVC ()<UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UILabel *idLB;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UIButton *sureBtn;
@property (nonatomic,strong)DeviceMaintRequest *manager;
@property (nonatomic,strong)DeviceBugRequest *fixManager;

@end

@implementation CarePostTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    UIColor *tempColor = [UIColor colorWithRed:219/255.0 green:219/255.0 blue:219/255.0 alpha:1];
    AddCornerBorder(self.textView, 2, 1, tempColor.CGColor);
    AddCornerBorder(self.sureBtn, 4, 0, nil)
    self.manager = [[DeviceMaintRequest alloc] init];
    self.fixManager = [[DeviceBugRequest alloc] init];
    self.idLB.text = [NSString stringWithFormat:@"编号：%@",self.task.deviceTaskId];
    
    if ([self.task.deviceImageType isEqualToString:@"DeviceBug"]) {
        self.title = @"电梯维修";
    }else{
        self.title = @"电梯维保";
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    [ProgressHUD dismiss];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        PUSH(@"Main", @"CacheVC", @"缓存", @{}, YES);
    }
}

- (IBAction)post:(id)sender {
    
    if (self.textView.text.length == 0) {
        [ProgressHUD showError:@"请输入描述!"];
        return;
    }
    [ProgressHUD show:@"保存中..."];
    self.task.taskDescription = self.textView.text;
    
    if ([self.task.deviceImageType isEqualToString:@"DeviceBug"]) {
        
        [self.fixManager uploadDeviceBugResultWithTaskResult:self.task response:^(NSString *errorMsg, UploadTaskResultModel *responseResultModel) {
            if (errorMsg.length > 0) {
                
                if (isCached(errorMsg)) {
                    
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:errorMsg
                                                                    message:@"已缓存至本地，是否查看？"
                                                                   delegate:self
                                                          cancelButtonTitle:@"取消"
                                                          otherButtonTitles:@"查看", nil];
                    [alert show];
                    
                }else{
                    [ProgressHUD showError:errorMsg];
                }
                
            }else{
                [ProgressHUD showSuccess:@"保存成功!"];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self.navigationController popToRootViewControllerAnimated:YES];
                });
                
                
            }
        }];
        
    }else{
        [self.manager uploadDeviceMainTaskWithTaskResult:self.task response:^(NSString *errorMsg, UploadTaskResultModel *responseResultModel) {
            if (errorMsg.length > 0) {
                if (isCached(errorMsg)) {
                    
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:errorMsg
                                                                    message:@"已缓存至本地，是否查看？"
                                                                   delegate:self
                                                          cancelButtonTitle:@"取消"
                                                          otherButtonTitles:@"查看", nil];
                    [alert show];
                    
                }else{
                    [ProgressHUD showError:errorMsg];
                }
            }else{
                [ProgressHUD showSuccess:@"保存成功!"];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self.navigationController popToRootViewControllerAnimated:YES];
                });
            }
            
            
        }];

    }
    
}

BOOL isCached(NSString *errorMsg)
{
    if ([errorMsg isEqualToString:@"请求超时"] ||
        [errorMsg isEqualToString:@"无法连接到网络"] ||
        [errorMsg isEqualToString:@"连接服务器失败，请稍后重试"]) {
        return YES;
    }
    return NO;
}

- (void)setTask:(TaskResult *)task
{
    _task = task;
    self.idLB.text = [NSString stringWithFormat:@"编号：%@",task.deviceTaskId];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0;
    }
    return 10;
}

@end
