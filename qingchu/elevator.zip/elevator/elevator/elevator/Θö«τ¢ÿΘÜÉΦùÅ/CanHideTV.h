//
//  CanHideTV.h
//  qingchu
//
//  Created by ZhuXiaoyan on 16/1/5.
//  Copyright © 2016年 whtriples. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HideKeyboardView.h"
@interface CanHideTV : UITextView

@end
