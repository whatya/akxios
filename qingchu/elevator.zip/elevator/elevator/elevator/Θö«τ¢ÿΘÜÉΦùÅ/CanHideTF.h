//
//  CanHideTF.h
//  qingchu
//
//  Created by ZhuXiaoyan on 15/9/17.
//  Copyright (c) 2015年 whtriples. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HideKeyboardView.h"
@interface CanHideTF : UITextField

@end
