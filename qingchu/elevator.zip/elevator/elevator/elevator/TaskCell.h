//
//  TaskCell.h
//  elevator
//
//  Created by 张宝 on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TaskCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *cameraIMV;
@property (weak, nonatomic) IBOutlet UILabel *contentLB;
@property (weak, nonatomic) IBOutlet UIImageView *tickLB;

@end
