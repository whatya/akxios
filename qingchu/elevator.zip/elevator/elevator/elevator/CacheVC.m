//
//  CacheVC.m
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "CacheVC.h"
#import "CommonConstants.h"
#import "TaskCoreDataManager.h"
#import "ProgressHUD.h"
#import "DeviceBugRequest.h"
#import "DeviceMaintRequest.h"
#import "TaskResult.h"

@interface CacheVC ()<
UITableViewDelegate,
UITableViewDataSource>

@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *btns;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) TaskCoreDataManager *coreDataManager;
@property (nonatomic,strong) NSMutableArray *caches;

@property (nonatomic,strong) DeviceBugRequest *fixManager;
@property (nonatomic,strong) DeviceMaintRequest *careManager;

@property (nonatomic,strong) NSMutableArray *toBeUploadedArray;

@end

@implementation CacheVC

#define CellID @"CacheCell"
#define NameTag 1973
#define NumbTag 1974
#define TextTag 1975
#define TimeTag 1976

- (void)viewDidLoad {
    [super viewDidLoad];
    self.coreDataManager = [[TaskCoreDataManager alloc] init];
    self.fixManager = [[DeviceBugRequest alloc]init];
    self.careManager = [[DeviceMaintRequest alloc] init];
    for (UIButton *btn in self.btns){
        AddCornerBorder(btn, 4, 0, nil)
    }
    self.caches = [NSMutableArray arrayWithArray:self.coreDataManager.allTasks];
    
    UIButton *checkBtn = self.btns[0];
    [checkBtn setTitle:@"全部选择" forState:UIControlStateNormal];
    [checkBtn setTitle:@"取消选中" forState:UIControlStateSelected];
    checkBtn.tintColor = [UIColor clearColor];
}

#define AllCheck 1977
#define SendThem 1978
#define RemoveIt 1979
- (IBAction)doSth:(UIButton *)sender {
    //删除操作
    if (sender.tag == RemoveIt) {
        NSMutableArray *beDeletedArray = [NSMutableArray new];
        for(int i = 0; i < self.caches.count;i++){
            Task *task = self.caches[i];
            if ([task.isChecked boolValue]) {
                [self.coreDataManager deleteTask:task.deviceTaskId];
                [beDeletedArray addObject:[NSIndexPath indexPathForRow:i inSection:0]];
            }
        }
        if (beDeletedArray.count > 0) {
            self.caches = [NSMutableArray arrayWithArray:self.coreDataManager.allTasks];
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:beDeletedArray withRowAnimation:UITableViewRowAnimationLeft];
            [self.tableView endUpdates];
        }else{
            [ProgressHUD showError:@"请至少选择一项!"];
        }
        //全选操作
    }else if (sender.tag == AllCheck && self.caches.count > 0){
        sender.selected = !sender.isSelected;
        for (int i = 0; i < self.caches.count;i++){
            Task *task = self.caches[i];
            if (sender.isSelected) {
                task.isChecked = [NSNumber numberWithBool:YES];
                [self.tableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0] animated:YES scrollPosition:UITableViewScrollPositionNone];
            }else{
                task.isChecked = [NSNumber numberWithBool:NO];
                [self.tableView deselectRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0] animated:YES];
            }
        }
        //发送操作
    }else if (sender.tag == SendThem){
        self.toBeUploadedArray = [NSMutableArray new];
        for (int i = 0; i < self.caches.count; i ++) {
            Task *coreDataTask  = self.caches[i];
            if ([coreDataTask.isChecked boolValue]) {
                TaskResult *upload = [[TaskResult alloc] init];
                upload.base64File = coreDataTask.base64File;
                upload.checkDateTime = coreDataTask.checkDateTime;
                upload.taskDescription = coreDataTask.taskDescription;
                upload.deviceImageType = coreDataTask.deviceImageType;
                upload.deviceTaskId = coreDataTask.deviceTaskId;
                upload.deviceNumber = coreDataTask.deviceNumber;
                upload.fileName = coreDataTask.fileName;
                upload.latitude = coreDataTask.latitude;
                upload.longitude = coreDataTask.longitude;
                upload.userLicenseCode = coreDataTask.userLicenseCode;
                [self.toBeUploadedArray addObject:upload];
            }
            
        }
        
        if (self.toBeUploadedArray.count > 0) {
            [ProgressHUD show:@"上传中..."];
            [self startUpload];
        }else{
            [ProgressHUD showError:@"请至少选择一项!"];
        }
        
    }
}

- (void)startUpload
{
    
    TaskResult *model = [self.toBeUploadedArray lastObject];
    
    
    if ([model.deviceImageType isEqualToString:@"DeviceBug"]) {
        
        [self.fixManager uploadDeviceBugResultWithTaskResult:model response:^(NSString *errorMsg, UploadTaskResultModel *responseResultModel) {
            
            if (errorMsg.length > 0) {
                [ProgressHUD showError:errorMsg];
            }else{
                [self.toBeUploadedArray removeObject:model];
                if (self.toBeUploadedArray.count > 0) {
                    [self startUpload];
                }else if (self.toBeUploadedArray.count == 0){
                    [ProgressHUD showSuccess:@"全部上传成功！"];
                }
                
                self.caches = [NSMutableArray arrayWithArray:self.coreDataManager.allTasks];
                [self.tableView reloadData];
            }
            
        }];
        
    }else{
        
        [self.careManager uploadDeviceMainTaskWithTaskResult:model response:^(NSString *errorMsg, UploadTaskResultModel *responseResultModel) {
            
            if (errorMsg.length > 0) {
                [ProgressHUD showError:errorMsg];
            }else{
                [self.toBeUploadedArray removeObject:model];
                if (self.toBeUploadedArray.count > 0) {
                    [self startUpload];
                }else if (self.toBeUploadedArray.count == 0){
                    [ProgressHUD showSuccess:@"全部上传成功！"];
                }
                self.caches = [NSMutableArray arrayWithArray:self.coreDataManager.allTasks];
                [self.tableView reloadData];
            }
            
        }];
        
    }
    
   
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  self.caches.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Task *model = self.caches[indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellID];
    //选中颜色
    UIView *tempView = [[UIView alloc] init];
    tempView.backgroundColor = SelectedColor;
    cell.selectedBackgroundView = tempView;
    
    cell.selected = [model.isChecked boolValue];
    
    UILabel *nameLB = [cell viewWithTag:NameTag];
    UILabel *numbLB = [cell viewWithTag:NumbTag];
    UILabel *textLB = [cell viewWithTag:TextTag];
    UILabel *timeLB = [cell viewWithTag:TimeTag];
    
    NSString *type = [model.deviceImageType isEqualToString:@"DeviceBug"] ? @"电梯维修" : @"电梯维保";
    nameLB.text = [NSString stringWithFormat:@"类别：%@",type];
    numbLB.text = [NSString stringWithFormat:@"编码：%@",model.deviceNumber];
    textLB.text = [NSString stringWithFormat:@"标注：%@", model.taskDescription];
    timeLB.text = [NSString stringWithFormat:@"时间：%@", model.checkDateTime];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    Task *model = self.caches[indexPath.row];
    model.isChecked = [NSNumber numberWithBool:YES];
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    Task *model = self.caches[indexPath.row];
    model.isChecked = [NSNumber numberWithBool:NO];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110;
}

@end
