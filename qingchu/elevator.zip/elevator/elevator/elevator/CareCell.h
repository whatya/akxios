//
//  CareCell.h
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DeviceMainTaskModel.h"
#import "TaskCell.h"

@interface CareCell : UITableViewCell
<UITableViewDelegate,
UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UILabel *nameLB;
@property (weak, nonatomic) IBOutlet UILabel *stateLB;
@property (weak, nonatomic) IBOutlet UILabel *timeLB;
@property (weak, nonatomic) IBOutlet UIImageView *arrowIMV;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) Ddevice *model;
@property(nonatomic,copy) void(^TaskSelect)(NSIndexPath *indexPath);

- (void)open;
- (void)close;

@end
