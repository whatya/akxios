//
//  TaskCoreDataManager.m
//  elevator
//
//  Created by 张宝 on 16/5/12.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "TaskCoreDataManager.h"
#import "AppDelegate.h"

@implementation TaskCoreDataManager

#pragma mark- 获取coredata工具类
- (CoreDataHelper *)coreDataHelper
{
    if (!_coreDataHelper) {
        _coreDataHelper = ((AppDelegate*)[[UIApplication sharedApplication] delegate]).coreDataHelper;
    }
    return _coreDataHelper;
}

- (NSString*)saveTask:(TaskResult *)taskResult
{
    //判断是否已经存在、如果已经缓存过就不再缓存
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"Task"];
    NSPredicate *filter = [NSPredicate predicateWithFormat:@"deviceTaskId == %@",taskResult.deviceTaskId];
    [request setPredicate:filter];
    NSArray *tasks = [self.coreDataHelper.context executeFetchRequest:request error:nil];
    if (tasks.count >  0) {
        return [NSString stringWithFormat:@"对象：%@已存在",taskResult.deviceTaskId];
    }
    
   Task *model = [NSEntityDescription insertNewObjectForEntityForName:@"Task" inManagedObjectContext:self.coreDataHelper.context];
    model.base64File = taskResult.base64File;
    model.checkDateTime = taskResult.checkDateTime;
    model.taskDescription = taskResult.taskDescription;
    model.deviceImageType = taskResult.deviceImageType;
    model.deviceTaskId = taskResult.deviceTaskId;
    model.deviceNumber = taskResult.deviceNumber;
    model.fileName = taskResult.fileName;
    model.latitude = taskResult.latitude;
    model.longitude = taskResult.longitude;
    model.userLicenseCode = taskResult.userLicenseCode;
    [self.coreDataHelper saveContext];
    return nil;
    
}

- (void)deleteTask:(NSString *)taskId
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"Task"];
    NSPredicate *filter = [NSPredicate predicateWithFormat:@"deviceTaskId == %@",taskId];
    [request setPredicate:filter];
    NSArray *tasks = [self.coreDataHelper.context executeFetchRequest:request error:nil];
    if (tasks.count >  0) {
        for (NSManagedObject *managedObject in tasks) {
            [self.coreDataHelper.context deleteObject:managedObject];
        }
        
        [self.coreDataHelper saveContext];

    }
}

- (NSArray *)allTasks
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"Task"];
    NSArray *tasks = [self.coreDataHelper.context executeFetchRequest:request error:nil];
    return tasks;
}

- (void)sync
{
    [self.coreDataHelper saveContext];
}

@end
