//
//  Sugar.h
//  elevator
//
//  Created by 张宝 on 16/5/9.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LoginModel.h"

#define k_username      @"username"
#define k_password      @"password"
#define k_userId        @"userid"
#define k_licenseCode   @"code"
#define k_userFullName  @"userFullName"

#define ROOT_URL        @"http://59.173.237.106:10002/"
#define k_root_url      @"rootUrl"

@interface Sugar : NSObject

//与loginUser中属性相同，为方便访问单独定义属性
@property(nonatomic,strong) NSString   *userFullName;
@property(nonatomic,strong) NSString   *userId;
@property(nonatomic,strong) NSString   *userLicenseCode;
@property(nonatomic,strong) NSString   *rootUrl;// http://59.173.237.106:10002/ 域名没有端口号

+ (Sugar *)shared;

+ (void)setLoginUser:(LoginModel *)loginUser;
+ (LoginModel *)loginUser;

@end
