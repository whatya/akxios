//
//  UserSetTVC.m
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "UserSetTVC.h"
#import "CommonConstants.h"
#import "ProgressHUD.h"
#import "Sugar.h"

@interface UserSetTVC ()

@property (weak, nonatomic) IBOutlet UIButton *saveBtn;
@property (weak, nonatomic) IBOutlet UITextField *usernameTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;
@property (weak, nonatomic) IBOutlet UITextField *urlTF;
@property (nonatomic,strong)LoginRequest *manager;

@end

@implementation UserSetTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置边框圆角
    AddCornerBorder(self.saveBtn, 4, 0, nil)
    self.manager = [[LoginRequest alloc] init];
    
    NSString *username = [Sugar loginUser].username ?: @"";
    NSString *password = [Sugar loginUser].password ?: @"";
    self.usernameTF.text = username;
    self.passwordTF.text = password;
    self.urlTF.text = [Sugar shared].rootUrl;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (IBAction)save:(id)sender
{
    //数据验证
    NSString *username = self.usernameTF.text;
    NSString *password = self.passwordTF.text;
    NSString *url      = self.urlTF.text;
    
    if (username.length == 0) { [ProgressHUD showError:@"请输入用户名!"];return;}
    if (password.length == 0) { [ProgressHUD showError:@"请输入密码!"];return;}
    if (url.length == 0) { [ProgressHUD showError:@"请输入根地址!"];return;}
    
    [Sugar shared].rootUrl = url;
    
    [ProgressHUD show:@"保存中..."];
    [self.manager loginWithUserName:username password:password response:^(NSString *errorMsg, LoginModel *loginModel) {
        
        //失败错误处理
        if (errorMsg) {
            [ProgressHUD showError:errorMsg];
            return ;
        }
        
        loginModel.username = username;
        loginModel.password = password;
        
        
        void(^temp)(NSString*,LoginModel*) = self.LoginAction;
        if (temp) {
            temp(errorMsg,loginModel);
            return;
        }
        
        //提交成功
        [ProgressHUD showSuccess:@"保存成功"];
        [Sugar setLoginUser:loginModel];
        [self.navigationController popToRootViewControllerAnimated:YES];
        
    }];
    
    
}



@end
