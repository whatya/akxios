//
//  ScannerVC.h
//  qingchu
//
//  Created by ZhuXiaoyan on 15/8/15.
//  Copyright (c) 2015年 whtriples. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScannerVC : UIViewController

@property(nonatomic,strong) UIViewController *delegate;

@end
