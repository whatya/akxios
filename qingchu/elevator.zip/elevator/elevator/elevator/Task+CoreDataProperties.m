//
//  Task+CoreDataProperties.m
//  elevator
//
//  Created by 张宝 on 16/5/13.
//  Copyright © 2016年 张宝. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Task+CoreDataProperties.h"

@implementation Task (CoreDataProperties)

@dynamic base64File;
@dynamic checkDateTime;
@dynamic deviceImageType;
@dynamic deviceNumber;
@dynamic deviceTaskId;
@dynamic fileName;
@dynamic latitude;
@dynamic longitude;
@dynamic taskDescription;
@dynamic userLicenseCode;
@dynamic isChecked;

@end
