//
//  Sugar.m
//  elevator
//
//  Created by 张宝 on 16/5/9.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "Sugar.h"
#import "CommonConstants.h"
@implementation Sugar

+ (Sugar *)shared
{
    static dispatch_once_t once = 0;
    static Sugar *sugar;
    dispatch_once(&once, ^{ sugar = [[Sugar alloc] init]; });
    return sugar;
}

+ (void)setLoginUser:(LoginModel *)loginUser
{
    save(k_username, loginUser.username);
    save(k_userId, loginUser.userId);
    save(k_licenseCode, loginUser.userLicenseCode);
    save(k_userFullName, loginUser.userFullName);
    save(k_password, loginUser.password);
}

+ (LoginModel *)loginUser
{
    LoginModel *temp = [[LoginModel alloc] init];
    temp.userFullName = stringValue(k_userFullName);
    temp.userId = stringValue(k_userId);
    temp.userLicenseCode = stringValue(k_licenseCode);
    temp.username = stringValue(k_username);
    temp.password = stringValue(k_password);
    return temp;
    
}

- (void)setUserFullName:(NSString *)userFullName
{
    save(k_username, userFullName);
}

- (NSString *)userFullName
{
    return stringValue(k_userFullName);
}

- (NSString *)rootUrl
{
    if (stringValue(k_root_url)) {
        return stringValue(k_root_url);
    }else{
        return ROOT_URL;
    }
}

- (void)setRootUrl:(NSString *)rootUrl
{
    save(k_root_url, rootUrl);
}

- (void)setUserId:(NSString *)userId
{
    save(k_userId, userId);
}

- (NSString *)userId
{
    return stringValue(k_userId);
}

- (NSString *)userLicenseCode
{
    return stringValue(k_licenseCode);
}

- (void)setUserLicenseCode:(NSString *)userLicenseCode
{
    save(k_licenseCode, userLicenseCode);
}


void save(NSString* key,NSString* value){
    if (StringNotEmpty(value)) {
        [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

NSString *stringValue(NSString* key){
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
}

@end
