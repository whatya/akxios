//
//  Task+CoreDataProperties.h
//  elevator
//
//  Created by 张宝 on 16/5/13.
//  Copyright © 2016年 张宝. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Task.h"

NS_ASSUME_NONNULL_BEGIN

@interface Task (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *base64File;
@property (nullable, nonatomic, retain) NSString *checkDateTime;
@property (nullable, nonatomic, retain) NSString *deviceImageType;
@property (nullable, nonatomic, retain) NSString *deviceNumber;
@property (nullable, nonatomic, retain) NSString *deviceTaskId;
@property (nullable, nonatomic, retain) NSString *fileName;
@property (nullable, nonatomic, retain) NSString *latitude;
@property (nullable, nonatomic, retain) NSString *longitude;
@property (nullable, nonatomic, retain) NSString *taskDescription;
@property (nullable, nonatomic, retain) NSString *userLicenseCode;
@property (nullable, nonatomic, retain) NSNumber *isChecked;

@end

NS_ASSUME_NONNULL_END
