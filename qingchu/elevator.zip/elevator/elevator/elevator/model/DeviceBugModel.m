//
//  DeviceBugModel.m
//  elevator
//
//  Created by caoguochi on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "DeviceBugModel.h"


@implementation DeviceBugDetail

+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"deviceBugDetail" : @"DeviceBugDetail",
             @"deviceBugId" : @"DeviceBugID",
             @"deviceName" :@"DeviceName"
             };
}


#define Padding 49
#define DetailHeight 17
#define CellHeight 60
- (CGFloat)cellHeight
{
    NSDictionary * attributes = @{NSFontAttributeName : [UIFont systemFontOfSize:14]};
    
    CGSize contentSize = [self.deviceBugDetail boundingRectWithSize:CGSizeMake(Screen_Width - Padding, MAXFLOAT)
                                                            options:(NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading)
                                                         attributes:attributes
                                                            context:nil].size;
    
    if (contentSize.height > DetailHeight) {
        return 60 + (contentSize.height - DetailHeight);
    }else{
        return 60;
    }

}


@end

@implementation DeviceBugModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"errorMessage" :@"ErrorMessage",
             @"pendingDeviceBugList" :@"PendingDeviceBugList"
             };
}

+ (NSValueTransformer *)pendingDeviceBugListJSONTransformer
{
    return [MTLJSONAdapter  arrayTransformerWithModelClass:[DeviceBugDetail class]];
}



@end
