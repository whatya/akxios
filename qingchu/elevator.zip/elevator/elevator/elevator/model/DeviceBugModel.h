//
//  DeviceBugModel.h
//  elevator
//
//  Created by caoguochi on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BaseModel.h"
#import <UIKit/UIKit.h>
#import "CommonConstants.h"

/**
 *  设备维修详情
 */
@interface DeviceBugDetail : BaseModel;

@property (nonatomic, strong) NSString *deviceBugDetail;
@property (nonatomic, strong) NSString *deviceBugId;
@property (nonatomic, strong) NSString *deviceName;
@property (nonatomic, assign) CGFloat  cellHeight;

@end

/**
 *  设备维修model
 */
@interface DeviceBugModel : BaseModel

/**
 *  维修bug列表,DeviceBugDetail类对象集合
 */
@property (nonatomic, strong) NSArray *pendingDeviceBugList;

@end
