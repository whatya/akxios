//
//  BaseModel.h
//  elevator
//
//  Created by caoguochi on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "MTLModel.h"
#import "Mantle.h"

@interface BaseModel : MTLModel <MTLJSONSerializing>

@property (nonatomic, strong) NSString *errorMessage;
@property (nonatomic, strong) NSString *errorCode;

@end
