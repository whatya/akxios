//
//  UploadTaskResultModel.h
//  elevator
//
//  Created by caoguochi on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BaseModel.h"

/**
 *  上传保养/维修结果响应Model
 */
@interface UploadTaskResultModel : BaseModel

@property (nonatomic, strong) NSString *virtualPath;

@end
