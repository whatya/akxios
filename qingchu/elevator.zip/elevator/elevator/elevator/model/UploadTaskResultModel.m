//
//  UploadTaskResultModel.m
//  elevator
//
//  Created by caoguochi on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "UploadTaskResultModel.h"

@implementation UploadTaskResultModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"errorMessage" : @"ErrorMessage",
             @"virtualPath" : @"VirtualPath"
             };
}

@end
