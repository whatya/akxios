//
//  TaskResult.h
//  elevator
//
//  Created by caoguochi on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  上传设备保养/维修结果参数类
 */
@interface TaskResult : NSObject

@property (nonatomic, strong) NSString *base64File;
@property (nonatomic, strong) NSString *checkDateTime;
@property (nonatomic, strong) NSString *taskDescription;
@property (nonatomic, strong) NSString *deviceImageType;
@property (nonatomic, strong) NSString *deviceTaskId;   // 设备保养/维修ID
@property (nonatomic, strong) NSString *deviceNumber;
@property (nonatomic, strong) NSString *fileName;
@property (nonatomic, strong) NSString *latitude;
@property (nonatomic, strong) NSString *longitude;
@property (nonatomic, strong) NSString *userLicenseCode;

@end
