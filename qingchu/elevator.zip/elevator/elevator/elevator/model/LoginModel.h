//
//  LoginModel.h
//  elevator
//
//  Created by caoguochi on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BaseModel.h"

@interface LoginModel : BaseModel

@property (nonatomic, strong) NSString *userFullName;
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *userLicenseCode;
@property (nonatomic, strong) NSString *username;
@property (nonatomic, strong) NSString *password;

@end
