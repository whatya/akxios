//
//  DeviceMainTaskModel.h
//  elevator
//
//  Created by caoguochi on 16/5/9.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BaseModel.h"
#import <UIKit/UIKit.h>
#import "CommonConstants.h"

/**
 *  保养任务详情
 */
@interface MaintTaskDetail : BaseModel

@property (nonatomic, assign) CGFloat cellHight;
@property (nonatomic, strong) NSString *isFinished;
@property (nonatomic, assign) BOOL needUploadImage;
@property (nonatomic, strong) NSString *taskDetailContent;
@property (nonatomic, strong) NSNumber *taskDetailID;
@property (nonatomic, strong) NSString *taskDetailTypeName;


@end

/**
 *  电梯设备Model
 */
@interface Ddevice : BaseModel

@property (nonatomic, assign) CGFloat cellHight;
@property (nonatomic, strong) NSNumber *deviceID;
@property (nonatomic, strong) NSString *deviceName;
@property (nonatomic, assign) BOOL isOpend;

/**
 *  保养任务详情列表，MaintTaskDetail对象数组
 */
@property (nonatomic, strong) NSArray *maintTaskDetailList;
@property (nonatomic, strong) NSString *statusName;
@property (nonatomic, strong) NSNumber *taskID;
@property (nonatomic, strong) NSString *taskName;
@property (nonatomic, strong) NSString *taskStartDate;

@end

/**
 *  电梯维护Model
 */
@interface DeviceMainTaskModel : BaseModel

/**
 *  电梯设备列表，Ddevice对象数组
 */
@property (nonatomic, strong) NSArray *maintTaskList;

@end
