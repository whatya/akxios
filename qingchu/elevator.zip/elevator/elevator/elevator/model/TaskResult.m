//
//  TaskResult.m
//  elevator
//
//  Created by caoguochi on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "TaskResult.h"

@implementation TaskResult

@end
