//
//  DeviceMainTaskModel.m
//  elevator
//
//  Created by caoguochi on 16/5/9.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "DeviceMainTaskModel.h"


@implementation MaintTaskDetail

+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"isFinished" : @"IsFinished",
             @"needUploadImage" : @"NeedUploadImage",
             @"taskDetailContent" : @"TaskDetailContent",
             @"taskDetailID" : @"TaskDetailID",
             @"taskDetailTypeName" : @"TaskDetailTypeName"
             };
}

#define Padding 93
#define TaskCellHeight 44
- (CGFloat)cellHight
{
    NSDictionary * attributes = @{NSFontAttributeName : [UIFont systemFontOfSize:14]};
    
    CGSize contentSize = [self.taskDetailContent boundingRectWithSize:CGSizeMake(Screen_Width - Padding, MAXFLOAT)
                                                 options:(NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading)
                                              attributes:attributes
                                                 context:nil].size;
    
    CGFloat height = contentSize.height + 12;
    
    return height > TaskCellHeight ? height : TaskCellHeight;
}

@end

@implementation Ddevice

+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"deviceID" : @"DeviceID",
             @"deviceName" : @"DeviceName",
             @"maintTaskDetailList" : @"PendingDeviceMaintTaskDetailList",
             @"statusName" : @"StatusName",
             @"taskID" : @"TaskID",
             @"taskName" : @"TaskName",
             @"taskStartDate" : @"TaskStartDate"
             };
}

+ (NSValueTransformer *)maintTaskDetailListJSONTransformer
{
    return [MTLJSONAdapter  arrayTransformerWithModelClass:[MaintTaskDetail class]];
}

#define DeviceHeight 80
- (CGFloat)cellHight
{
    if (self.isOpend) {
        if (self.maintTaskDetailList.count > 0) {
            
            float sum = 0;
            for(MaintTaskDetail *model in self.maintTaskDetailList){
                sum += model.cellHight;
            }
            return sum + DeviceHeight;
            
        }else{
            return DeviceHeight;
        }

    }else{
        return DeviceHeight;
    }
    
}

@end

@implementation DeviceMainTaskModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"errorMessage" : @"ErrorMessage",
             @"maintTaskList" : @"PendingDeviceMaintTaskList"
             };
}

+ (NSValueTransformer *)maintTaskListJSONTransformer
{
    return [MTLJSONAdapter  arrayTransformerWithModelClass:[Ddevice class]];
}

@end
