//
//  LoginModel.m
//  elevator
//
//  Created by caoguochi on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "LoginModel.h"

@implementation LoginModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey
{
    return @{
             @"errorMessage" : @"ErrorMessage",
             @"userFullName" : @"UserFullName",
             @"userId" : @"UserId",
             @"userLicenseCode" : @"UserLicenseCode"
             };
}

@end
