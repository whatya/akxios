//
//  BugListVC.m
//  elevator
//
//  Created by 张宝 on 16/5/12.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BugListVC.h"
#import "DeviceBugRequest.h"
#import "ProgressHUD.h"
#import "Tracker.h"
#import "Sugar.h"

@interface BugListVC ()
<UITableViewDelegate,
UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *bugs;
@property (nonatomic,strong) DeviceBugRequest *manager;
//选中id
@property (nonatomic,strong) NSString *selectedTaskID;

@end

@implementation BugListVC

#define CellID @"BugCell"
#define NameTag 1973
#define TextTag 1974

- (void)viewDidLoad {
    [super viewDidLoad];
    self.bugs = [NSMutableArray new];
    self.manager = [[DeviceBugRequest alloc] init];
    [self bugList];
}

- (void)bugList
{
    [ProgressHUD show:@"获取中..."];
    [self.manager getPendingDeviceBug:^(NSString *errorMsg, NSArray *bugDetailList) {
       
        if (errorMsg.length > 0) {
            [ProgressHUD showError:errorMsg];
            return ;
        }
        
        [ProgressHUD dismiss];
        [self.bugs addObjectsFromArray:bugDetailList];
        [self.tableView reloadData];
        
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.bugs.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DeviceBugDetail *model = self.bugs[indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellID];
    UILabel *nameLB = [cell viewWithTag:NameTag];
    UILabel *textLB = [cell viewWithTag:TextTag];
    nameLB.text = model.deviceName;
    textLB.text = model.deviceBugDetail;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DeviceBugDetail *model = self.bugs[indexPath.row];
    return model.cellHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DeviceBugDetail *model = self.bugs[indexPath.row];
    self.selectedTaskID = model.deviceBugId;
    UINavigationController *nav = VCFromStoryboard(@"Main", @"ScannerNav");
    [nav.topViewController setValue:self forKey:@"delegate"];
    [self presentViewController:nav animated:YES completion:NULL];
    
}

- (void)setBarCode:(NSString *)barCode
{
    _barCode = barCode;
    [ProgressHUD show:@"处理中..."];
    NSLog(@"barcode got:%@",barCode);
    //提交参数model
    TaskResult *task = [[TaskResult alloc] init];
    task.checkDateTime = [self currentDateString];//上传时间
    task.deviceImageType = @"DeviceBug";//维修／保养
    task.deviceTaskId = self.selectedTaskID;//任务id
    task.deviceNumber = barCode;//二维码
    task.fileName = @"";
    task.latitude = [NSString stringWithFormat:@"%.4f",[Tracker shared].lat];
    task.longitude = [NSString stringWithFormat:@"%.4f",[Tracker shared].lon];
    task.userLicenseCode = [Sugar loginUser].userLicenseCode;
    
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        PUSH(@"Main", @"ImageMakerVC", @"照片", @{@"task":task}, YES);
    });
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    [ProgressHUD dismiss];
}

- (NSString*)currentDateString
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    return [formatter stringFromDate:[NSDate date]];
}

@end
