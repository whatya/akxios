//
//  Task.m
//  elevator
//
//  Created by 张宝 on 16/5/12.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "Task.h"

@implementation Task

// Insert code here to add functionality to your managed object subclass

@end
