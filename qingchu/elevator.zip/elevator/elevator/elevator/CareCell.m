//
//  CareCell.m
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "CareCell.h"

@implementation CareCell

#define CellID @"TaskCell"

- (void)awakeFromNib {
    [super awakeFromNib];
    [self updateUI];
}

- (void)setModel:(Ddevice *)model
{
    _model = model;
    [self updateUI];
    
}

- (void)open
{
    [UIView animateWithDuration:0.2 animations:^{
        self.arrowIMV.transform=CGAffineTransformMakeRotation(M_PI/2);
    }];
}

- (void)close
{
    [UIView animateWithDuration:0.2 animations:^{
        self.arrowIMV.transform = CGAffineTransformMakeRotation(0);
    }];
    
}

- (void)updateUI
{
    //设置箭头方向
   self.arrowIMV.transform = self.model.isOpend ? CGAffineTransformMakeRotation(M_PI/2) : CGAffineTransformMakeRotation(0);
    //设备cell设置
    self.nameLB.text = self.model.deviceName;
    self.timeLB.text = [NSString stringWithFormat:@"开始时间:%@",self.model.taskStartDate];
    self.stateLB.text = self.model.statusName;
    //下级子任务设置
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.model.maintTaskDetailList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
     MaintTaskDetail *task = self.model.maintTaskDetailList[indexPath.row];
    return task.cellHight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TaskCell *cell = [tableView dequeueReusableCellWithIdentifier:CellID];
    
    MaintTaskDetail *task = self.model.maintTaskDetailList[indexPath.row];
    
    cell.contentLB.text = task.taskDetailContent;
    
    cell.cameraIMV.hidden = !task.needUploadImage;
    
    cell.tickLB.hidden = ![task.isFinished boolValue];
    
    UIView *temp = [[UIView alloc] init];
    temp.backgroundColor = SelectedColor;
    
    cell.selectedBackgroundView = temp;
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    void (^temp)(NSIndexPath *index) = self.TaskSelect;
    if (temp) {
        temp(indexPath);
    }
}

@end
