//
//  TrackerView.m
//  elevator
//
//  Created by 张宝 on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "TrackerView.h"
#import "CommonConstants.h"

@implementation TrackerView

- (void)awakeFromNib
{
    
    
    UIFont  *textFont = [UIFont systemFontOfSize:15];
    self.timeLB = [[UILabel alloc] initWithFrame:CGRectMake(8, 12, Screen_Width - 16, 18)];
    self.timeLB.font = textFont;
    
    self.lonLB = [[UILabel alloc] initWithFrame:CGRectMake(8, 42, Screen_Width - 16, 18)];
    self.lonLB.font = textFont;
    
    self.latLB = [[UILabel alloc] initWithFrame:CGRectMake(8, 72, Screen_Width - 16, 18)];
    self.latLB.font = textFont;
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSString *dateStr = [formatter stringFromDate:[Tracker shared].currentDate];
    self.timeLB.text = [NSString stringWithFormat:@"时间：%@",dateStr];
    self.lonLB.text = [NSString stringWithFormat:@"经度：%f",[Tracker shared].lon];
    self.latLB.text = [NSString stringWithFormat:@"纬度：%f",[Tracker shared].lat];
    
    [self addSubview:self.timeLB];
    [self addSubview:self.lonLB];
    [self addSubview:self.latLB];
    
    [[Tracker shared] addObserver:self
                       forKeyPath:@"currentDate"
                          options:NSKeyValueObservingOptionNew
                          context:NULL];
    
    [[Tracker shared] addObserver:self
                       forKeyPath:@"lon"
                          options:NSKeyValueObservingOptionNew
                          context:NULL];
    
    [[Tracker shared] addObserver:self
                       forKeyPath:@"lat"
                          options:NSKeyValueObservingOptionNew
                          context:NULL];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if([keyPath isEqualToString:@"currentDate"])
    {
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        NSString *dateStr = [formatter stringFromDate:[Tracker shared].currentDate];
        self.timeLB.text = [NSString stringWithFormat:@"时间：%@",dateStr];
    }else if ([keyPath isEqualToString:@"lon"]){
        
        self.lonLB.text = [NSString stringWithFormat:@"经度：%f",[Tracker shared].lon];
        
    }else if ([keyPath isEqualToString:@"lat"]){
        
        self.latLB.text = [NSString stringWithFormat:@"纬度：%f",[Tracker shared].lat];
        
    }
}

- (void)dealloc
{
    [[Tracker shared] removeObserver:self forKeyPath:@"currentDate"];
    [[Tracker shared] removeObserver:self forKeyPath:@"lon"];
    [[Tracker shared] removeObserver:self forKeyPath:@"lat"];

}

@end
