//
//  HomeTVC.m
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "HomeTVC.h"
#import "CommonConstants.h"
#import "Sugar.h"
#import "ProgressHUD.h"

@interface HomeTVC ()

@property (weak, nonatomic) IBOutlet UILabel *nameLB;
@property (weak, nonatomic) IBOutlet UILabel *codeLB;

@end

@implementation HomeTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [self login];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    NSString *name = [Sugar shared].userFullName ?: @"";
    NSString *code = [Sugar shared].userLicenseCode ?: @"";
    self.nameLB.text = [NSString stringWithFormat:@"认证操作者：%@",name];
    self.codeLB.text = [NSString stringWithFormat:@"操作者编号：%@",code];
}

- (void)login
{
    if (![Sugar loginUser].userId) {
        UINavigationController *nav = VCFromStoryboard(@"Main", @"LoginNav");
        UIViewController *vc = nav.topViewController;
        __weak HomeTVC *weak_self = self;
        void(^tempAction)(NSString*,LoginModel*) = ^(NSString* errorString,LoginModel* user){
            [ProgressHUD showSuccess:@"保存成功！"];
            [Sugar setLoginUser:user];
            [weak_self dismissViewControllerAnimated:YES completion:NULL];
            
        };
        [vc setValue:tempAction forKey:@"LoginAction"];
        [self presentViewController:nav animated:YES completion:NULL];
    }
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
