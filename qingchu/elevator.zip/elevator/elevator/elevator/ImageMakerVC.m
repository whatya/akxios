//
//  ImageMakerVC.m
//  elevator
//
//  Created by 张宝 on 16/5/9.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "ImageMakerVC.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "CommonConstants.h"
#import "LoginModel.h"
#import "Sugar.h"
#import "Tracker.h"
#import "ProgressHUD.h"

@interface ImageMakerVC ()
<UINavigationControllerDelegate,
UIImagePickerControllerDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *idLB;
@property (weak, nonatomic) IBOutlet UILabel *timeLB;
@property (weak, nonatomic) IBOutlet UILabel *placeLB;
@property (weak, nonatomic) IBOutlet UILabel *userLB;
@property (weak, nonatomic) IBOutlet UILabel *typeLB;

@property (nonatomic,strong) UIImage *orignalImage;

@end

@implementation ImageMakerVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addCarema];
}
- (IBAction)retake:(id)sender {
    [self addCarema];
}

- (void)setTask:(TaskResult *)task
{
    _task = task;
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"UploadSegue"]) {
        
        if (!self.orignalImage) {return;}
        //转为jpg
        
        UIImage *image = [self imageCompressForWidth:self.orignalImage targetWidth:550];
        UIImage *textImage = [self addTextTo:image];
        UIImage *image500 = [self imageCompressForWidth:textImage targetWidth:550];
        NSData *imageData = UIImageJPEGRepresentation(image500, 1);
        
        
        NSString *baseStr = [imageData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithCarriageReturn];
        self.task.base64File = baseStr;
        self.task.fileName = @"ios_upload.jpg";
        [segue.destinationViewController setValue:self.task forKey:@"task"];
        
    }
}

- (UIImage*)addTextTo:(UIImage*)image
{
    LoginModel *user = [Sugar loginUser];
    Tracker *location = [Tracker shared];
    
    NSDictionary *attrs = @{ NSFontAttributeName :[ UIFont fontWithName : @"Arial-BoldMT" size:15 ],
                             NSForegroundColorAttributeName :[ UIColor redColor ] };
    //编码
    ImageString *idStr = [[ImageString alloc] init];
    idStr.string = [NSString stringWithFormat:@"编码：%@",self.task.deviceNumber];
    idStr.attributes = attrs;
    idStr.point = CGPointMake(20, 20);
    
    //位置
    ImageString *placeStr = [[ImageString alloc] init];
    placeStr.string = [NSString stringWithFormat:@"位置：%.4f,%.4f",location.lon,location.lat];
    placeStr.attributes = attrs;
    placeStr.point = CGPointMake(20, 50);
    
    //操作证
    ImageString *licenseStr = [[ImageString alloc] init];
    licenseStr.string = [NSString stringWithFormat:@"操作证：%@",user.userLicenseCode];
    licenseStr.attributes = attrs;
    licenseStr.point = CGPointMake(20, 80);
    
    //时间
    ImageString *dateStr = [[ImageString alloc] init];
    dateStr.string = [NSString stringWithFormat:@"时间：%@",[self currentDateStr]];
    dateStr.attributes = attrs;
    dateStr.point = CGPointMake(300, 20);
    
    //用户
    ImageString *userStr = [[ImageString alloc] init];
    userStr.string = [NSString stringWithFormat:@"用户：%@",user.userFullName];
    userStr.attributes = attrs;
    userStr.point = CGPointMake(300, 50);
    
    //操作类型
    ImageString *typeStr = [[ImageString alloc] init];
    NSString *type = [self.task.deviceImageType isEqualToString:@"DeviceBug"] ? @"电梯维修":@"电梯保养";
    typeStr.string = [NSString stringWithFormat:@"操作类型：%@",type];
    typeStr.attributes = attrs;
    typeStr.point = CGPointMake(300, 80);
    
    UIImage *textImage = [self drawStrings:@[idStr,placeStr,licenseStr,dateStr,userStr,typeStr] onImage:image];
    return textImage;
}

- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    if ([identifier isEqualToString:@"UploadSegue"]) {
        if (self.orignalImage) {
            return YES;
        }else{
            [ProgressHUD showError:@"请上传图片！"];
            return NO;
        }
    }
    return YES;
}

-(void)addCarema
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:^{}];
    
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    UIImage *editImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    [self dismissViewControllerAnimated:YES completion:^{
        
        self.orignalImage = editImage;
        //按宽度比例压缩
        UIImage *scaledImage = [self imageCompressForWidth:editImage targetWidth:550];
        //添加文字
        UIImage *textImage = [self addTextTo:scaledImage];
        //添加到视图上面
        self.imageView.image = textImage;

    }];
    
}

#pragma mark- 图片按比例压缩
- (UIImage *)imageCompressForSize:(UIImage *)sourceImage targetSize:(CGSize)size{
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = size.width;
    CGFloat targetHeight = size.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0, 0.0);
    if(CGSizeEqualToSize(imageSize, size) == NO){
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        if(widthFactor > heightFactor){
            scaleFactor = widthFactor;
        }
        else{
            scaleFactor = heightFactor;
        }
        scaledWidth = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        if(widthFactor > heightFactor){
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }else if(widthFactor < heightFactor){
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    
    UIGraphicsBeginImageContext(size);
    
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    [sourceImage drawInRect:thumbnailRect];
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    if(newImage == nil){
        NSLog(@"scale image fail");
    }
    
    UIGraphicsEndImageContext();
    
    return newImage;
    
}

#pragma mark- 图片按宽度比例压缩
-(UIImage *) imageCompressForWidth:(UIImage *)sourceImage targetWidth:(CGFloat)defineWidth{
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = defineWidth;
    CGFloat targetHeight = height / (width / targetWidth);
    CGSize size = CGSizeMake(targetWidth, targetHeight);
    CGFloat scaleFactor = [UIScreen mainScreen].scale;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0, 0.0);
    if(CGSizeEqualToSize(imageSize, size) == NO){
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        if(widthFactor > heightFactor){
            scaleFactor = widthFactor;
        }
        else{
            scaleFactor = heightFactor;
        }
        scaledWidth = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        if(widthFactor > heightFactor){
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }else if(widthFactor < heightFactor){
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    UIGraphicsBeginImageContext(size);
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil){
        NSLog(@"scale image fail");
    }
    
    UIGraphicsEndImageContext();
    return newImage;
}

#pragma mark- 图片添加文字
- ( UIImage *)drawStrings:(NSArray*)strings onImage:(UIImage*)image

{
    CGSize size= CGSizeMake (image.size.width, image.size.height ); // 画布大小
    
    UIGraphicsBeginImageContextWithOptions (size, NO , [UIScreen mainScreen].scale );
    
    [image drawAtPoint : CGPointMake ( 0 , 0 )];
    
    // 获得一个位图图形上下文
    
    CGContextRef context= UIGraphicsGetCurrentContext ();
    
    CGContextDrawPath (context, kCGPathStroke );
    
    // 画 打败了多少用户
    
    for (ImageString *imageString in strings){
        [imageString.string drawAtPoint:imageString.point withAttributes:imageString.attributes];
    }
    
    UIImage *newImage= UIGraphicsGetImageFromCurrentImageContext ();
    
    UIGraphicsEndImageContext ();
    
    return newImage;
    
}

- (NSString*)currentDateStr
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    return [formatter stringFromDate:[NSDate date]];
}

@end

@implementation ImageString

@end
