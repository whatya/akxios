//
//  ImageMakerVC.h
//  elevator
//
//  Created by 张宝 on 16/5/9.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TaskResult.h"
@interface ImageMakerVC : UIViewController

@property(nonatomic,strong) TaskResult *task;

@end

@interface ImageString : NSObject

@property(nonatomic,strong) NSString *string;
@property(nonatomic,strong) NSDictionary *attributes;
@property(nonatomic,assign) CGPoint point;

@end
