//
//  AppDelegate.m
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "AppDelegate.h"
#import "Tracker.h" 


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //设置导航栏tint颜色
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    //设置导航栏字体和颜色
    NSMutableDictionary *textAttrs=[NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName]=[UIColor whiteColor];
    [[UINavigationBar appearance] setTitleTextAttributes:textAttrs];
    //设置状态栏为白色
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    
    //启动定位
    [[Tracker shared] initLocationManager];
    [[Tracker shared] currentTime];
    
    return YES;
}

#pragma mark- 初始化coredata
- (CoreDataHelper *)cdh
{
    if (!_coreDataHelper) {
        _coreDataHelper = [CoreDataHelper new];
        [_coreDataHelper setupCoreCata];
    }
    return _coreDataHelper;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    [[self cdh] saveContext];
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    [[self cdh] saveContext];
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    [[self cdh] saveContext];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[self cdh] saveContext];
}

- (void)applicationWillTerminate:(UIApplication *)application {
    [[self cdh] saveContext];
}

@end
