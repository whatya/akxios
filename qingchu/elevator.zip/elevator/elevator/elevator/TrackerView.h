//
//  TrackerView.h
//  elevator
//
//  Created by 张宝 on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Tracker.h"

@interface TrackerView : UIView

@property (nonatomic, strong) UILabel *timeLB;
@property (nonatomic, strong) UILabel *lonLB;
@property (nonatomic, strong) UILabel *latLB;


@end
