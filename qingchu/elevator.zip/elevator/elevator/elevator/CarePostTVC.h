//
//  CarePostTVC.h
//  elevator
//
//  Created by 张宝 on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TaskResult.h"
@interface CarePostTVC : UITableViewController

@property(nonatomic, strong) TaskResult *task;

@end
