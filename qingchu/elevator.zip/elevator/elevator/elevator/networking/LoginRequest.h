//
//  LoginRequest.h
//  elevator
//
//  Created by caoguochi on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BaseRequest.h"
#import "LoginModel.h"

/**
 *  登陆回调，如果errorMsg不为空，表示登陆异常
 *
 *  @param msg        登陆返回信息
 *  @param loginModel 登陆返回对象
 */
typedef void (^loginBlock) (NSString *errorMsg, LoginModel *loginModel);

@interface LoginRequest : BaseRequest

/**
 *  登陆请求
 *
 *  @param username      用户名
 *  @param password      密码
 *  @param loginResponse 登陆回调
 */
- (void)loginWithUserName:(NSString *)username password:(NSString *)password response:(loginBlock)loginResponse;



@end
