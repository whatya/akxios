//
//  DeviceBugRequest.m
//  elevator
//
//  Created by caoguochi on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "DeviceBugRequest.h"
#import "TaskCoreDataManager.h"

@implementation DeviceBugRequest

- (void)getPendingDeviceBug:(bugTaskBlock)response
{
    self.url = GetPendingDeviceBug_URL;
    [self postRequest:^(id responseObject) {
        NSError *error = [[NSError alloc]init];
        DeviceBugModel *bugModel = [MTLJSONAdapter modelOfClass:[DeviceBugModel class] fromJSONDictionary:responseObject error:&error];
        
        response(bugModel.errorMessage, bugModel.pendingDeviceBugList);
        
    } faile:^(NSString *errorMsg) {
        
        response(errorMsg, nil);
    }];
}

- (void)uploadDeviceBugResultWithTaskResult:(TaskResult *)taskResult response:(uploadBugBlock)response
{
    self.url = UploadDeviceBugResult_URL;
    [self.parameter setObject:taskResult.base64File      forKey:@"Base64File"];
    [self.parameter setObject:taskResult.checkDateTime   forKey:@"CheckDateTime"];
    [self.parameter setObject:taskResult.taskDescription forKey:@"Description"];
    [self.parameter setObject:taskResult.deviceTaskId    forKey:@"DeviceBugID"];
    [self.parameter setObject:taskResult.deviceNumber    forKey:@"DeviceNumber"];
    [self.parameter setObject:taskResult.fileName        forKey:@"FileName"];
    [self.parameter setObject:taskResult.latitude        forKey:@"Latitude"];
    [self.parameter setObject:taskResult.longitude       forKey:@"Longitude"];
    [self.parameter setObject:taskResult.userLicenseCode forKey:@"UserLicenseCode"];
    [self.parameter setObject:taskResult.deviceImageType forKey:@"DeviceImageType"];
    
    TaskCoreDataManager *task = [[TaskCoreDataManager alloc]init];
    [task saveTask:taskResult];
    
    [self postRequest:^(id responseObject) {
        
        UploadTaskResultModel *resultModel =  [MTLJSONAdapter modelOfClass:[UploadTaskResultModel class] fromJSONDictionary:responseObject error:nil];
        [task deleteTask:taskResult.deviceTaskId];
        response(resultModel.errorMessage, resultModel);
    } faile:^(NSString *errorMsg) {
        
        response(errorMsg, nil);
    }];
}

@end
