//
//  DeviceMaintRequest.m
//  elevator
//
//  Created by caoguochi on 16/5/9.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "DeviceMaintRequest.h"
#import "TaskCoreDataManager.h"

@implementation DeviceMaintRequest

- (void)getPendingDeviceMaintTask:(maintTaskBlock)mainTask
{
    self.url = GetDevicMaintTask_URL;
    [self postRequest:^(id responseObject) {
        
        DeviceMainTaskModel *task = [MTLJSONAdapter modelOfClass:[DeviceMainTaskModel class] fromJSONDictionary:responseObject error:nil];
        
        mainTask(task.errorMessage, task.maintTaskList);
        
    } faile:^(NSString *errorMsg) {
        
        mainTask(errorMsg, nil);
    }];
}

- (void)uploadDeviceMainTaskWithTaskResult:(TaskResult *)taskResult response:(uploudMaintTaskBlock) responseBlock
{
    self.url = UploadDeviceMainTask_URL;
    [self.parameter setObject:taskResult.base64File      forKey:@"Base64File"];
    [self.parameter setObject:taskResult.checkDateTime   forKey:@"CheckDateTime"];
    [self.parameter setObject:taskResult.taskDescription forKey:@"Description"];
    [self.parameter setObject:taskResult.deviceTaskId    forKey:@"DeviceMaintTaskDetailID"];
    [self.parameter setObject:taskResult.deviceNumber    forKey:@"DeviceNumber"];
    [self.parameter setObject:taskResult.fileName        forKey:@"FileName"];
    [self.parameter setObject:taskResult.latitude        forKey:@"Latitude"];
    [self.parameter setObject:taskResult.longitude       forKey:@"Longitude"];
    [self.parameter setObject:taskResult.userLicenseCode forKey:@"UserLicenseCode"];
    [self.parameter setObject:taskResult.deviceImageType forKey:@"DeviceImageType"];
    
    TaskCoreDataManager *task = [[TaskCoreDataManager alloc]init];
    [task saveTask:taskResult];
    
    [self postRequest:^(id responseObject) {
        
        UploadTaskResultModel *resultModel =  [MTLJSONAdapter modelOfClass:[UploadTaskResultModel class] fromJSONDictionary:responseObject error:nil];
        [task deleteTask:taskResult.deviceTaskId];
        responseBlock(resultModel.errorMessage, resultModel);
        
    } faile:^(NSString *errorMsg) {
        responseBlock(errorMsg, nil);
    }];
}

@end
