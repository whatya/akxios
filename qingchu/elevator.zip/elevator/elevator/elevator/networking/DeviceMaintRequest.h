//
//  DeviceMaintRequest.h
//  elevator
//
//  Created by caoguochi on 16/5/9.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BaseRequest.h"
#import "DeviceMainTaskModel.h"
#import "TaskResult.h"
#import "UploadTaskResultModel.h"

/**
 *  获取保养列表block
 *
 *  @param errorMsg      错误信息
 *  @param maintTaskList 保养列表,Ddevice对象列表
 */
typedef void (^maintTaskBlock) (NSString *errorMsg, NSArray *maintTaskList);

/**
 *  上传保养结果响应block
 *
 *  @param errorMsg    错误信息
 *  @param resultModel 响应返回model
 */
typedef void (^uploudMaintTaskBlock) (NSString *errorMsg, UploadTaskResultModel *responseResultModel);

@interface DeviceMaintRequest : BaseRequest

/**
 *  获取用户维保计划列表
 *
 */
- (void)getPendingDeviceMaintTask:(maintTaskBlock)mainTask;

/**
 *  上传保养结果
 *
 *  @param taskResult     保养结果参数类
 *  @param responseBlock  响应返回block
 */
- (void)uploadDeviceMainTaskWithTaskResult:(TaskResult *)taskResult response:(uploudMaintTaskBlock) responseBlock;

@end
