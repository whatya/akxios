//
//  BaseRequest.m
//  elevator
//
//  Created by caoguochi on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BaseRequest.h"
#import "AFNetworking.h"
#import "Sugar.h"

@interface BaseRequest ()

@property (nonatomic, strong) AFHTTPSessionManager *manager;

@end

@implementation BaseRequest

- (id)init
{
    self = [super init];
    if (self)
    {
        
        //        self.manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[NSURL URLWithString:baseUrl]];
        self.manager = [AFHTTPSessionManager manager];
        self.parameter = [NSMutableDictionary dictionary];
        Sugar *s = [Sugar shared];
        if(StringNotEmpty(s.userFullName))
        {
            [self.parameter setObject:s.userFullName forKey:@"UserFullName"];
        }
        if(StringNotEmpty(s.userId))
        {
            [self.parameter setObject:s.userId forKey:@"UserId"];
        }
    }
    return self;
}

- (void)getRequest:(successBlock)success faile:(failBlock)fail;
{
    NSString *urlStr = [NSString stringWithFormat:@"%@%@",[Sugar shared].rootUrl,self.url];
    //解决中文编码
    urlStr = [urlStr stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    [self.manager GET:urlStr parameters:self.parameter progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@",responseObject);
        success(responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSString *errorMsg = [self getErrorMessageWithErrorCode:error.code];
        fail(errorMsg);
    }];
}

- (void)postRequest:(successBlock)success faile:(failBlock)fail
{
    NSString *urlStr = [NSString stringWithFormat:@"%@%@",[Sugar shared].rootUrl,self.url];
    //解决中文编码
    urlStr = [urlStr stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    self.manager.requestSerializer = [AFJSONRequestSerializer serializer];//使用这个将得到的是JSON
    [self.manager.responseSerializer setAcceptableContentTypes: [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", nil]];
    
    [self.manager POST:urlStr parameters:self.parameter progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@",responseObject);
        success(responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSString *errorMsg = [self getErrorMessageWithErrorCode:error.code];
        NSLog(@"%@",error);
        fail(errorMsg);
    }];
}

- (NSString *)getErrorMessageWithErrorCode:(NSInteger)code
{
    if(code == -1001)  return @"请求超时";
    if(code == -1009)  return @"无法连接到网络";
    if(code == -1004)  return @"连接服务器失败，请稍后重试";
    return @"失败";
}

@end
