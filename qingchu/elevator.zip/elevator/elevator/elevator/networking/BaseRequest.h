//
//  BaseRequest.h
//  elevator
//
//  Created by caoguochi on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NetworkingConstant.h"
#import "CommonConstants.h"

typedef void (^responseBlock) (NSObject *response);
typedef void (^successBlock) (id  responseObject);
typedef void (^failBlock) (NSString *errorMsg);

@interface BaseRequest : NSObject
/**
 *  请求URL宏
 */
@property (nonatomic, strong) NSString *url;

/**
 *  请求所需参数
 */
@property (nonatomic, strong) NSMutableDictionary *parameter;

/**
 *  发起get请求
 *
 */
- (void)getRequest:(successBlock)success faile:(failBlock)fail;

/**
 *  发起post请求
 *
 */
- (void)postRequest:(successBlock)success faile:(failBlock)fail;

@end
