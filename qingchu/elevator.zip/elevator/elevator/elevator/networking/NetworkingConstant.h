//
//  NetworkingConstant.h
//  elevator
//
//  Created by caoguochi on 16/5/8.
//  Copyright © 2016年 张宝. All rights reserved.
//

#ifndef NetworkingConstant_h
#define NetworkingConstant_h


#endif /* NetworkingConstant_h */


#define LOGIN_URL                   @"WcfService/AppService.svc/User/Login"                               //登陆
#define GetDevicMaintTask_URL       @"WcfService/AppService.svc/DeviceMaint/GetPendingDeviceMaintTask"   //获取保养任务列表
#define UploadDeviceMainTask_URL    @"WcfService/AppService.svc/DeviceMaint/UploadDeviceMaintTaskResult" //上传保养结果
#define GetPendingDeviceBug_URL     @"WcfService/AppService.svc/DeviceBug/GetPendingDeviceBug"           //获取维修列表
#define UploadDeviceBugResult_URL   @"WcfService/AppService.svc/DeviceBug/UploadDeviceBugResult"         //上传维修结果