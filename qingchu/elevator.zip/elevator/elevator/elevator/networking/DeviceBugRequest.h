//
//  DeviceBugRequest.h
//  elevator
//
//  Created by caoguochi on 16/5/11.
//  Copyright © 2016年 张宝. All rights reserved.
//

#import "BaseRequest.h"
#import "DeviceBugModel.h"
#import "TaskResult.h"
#import "UploadTaskResultModel.h"

/**
 *  获取维修列表
 *
 *  @param errorMsg    错误信息
 *  @param bugTaskList 维修详情列表，DeviceBugDetail对象结合
 */
typedef void (^bugTaskBlock) (NSString *errorMsg, NSArray *bugDetailList);

/**
 *  上传维修结果响应block
 *
 *  @param errorMsg            错误信息
 *  @param responseResultModel 响应返回model
 */
typedef void (^uploadBugBlock)(NSString *errorMsg, UploadTaskResultModel *responseResultModel);

@interface DeviceBugRequest : BaseRequest

/**
 *  获取维修列表
 *
 */
- (void)getPendingDeviceBug:(bugTaskBlock)response;

/**
 *  上传维修结果
 *
 *  @param taskResult  维修结果
 *  @param response   响应返回block
 */
- (void)uploadDeviceBugResultWithTaskResult:(TaskResult *)taskResult response:(uploadBugBlock)response;

@end
